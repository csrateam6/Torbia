# torbia-range-provisioning

Ansible + PowerShell for setting up the **Torbia cyber-range** user accounts,
over SSH (Linux) and on the Domain Controller (Windows), as `csra_admin`.

> **Exercise/lab use only.** Weak passwords by design. Do not point at production.

## Two workflows — pick one

**A) MIGRATE (current approach)** — rename the existing baseline accounts to the
new S. Torbia names and **keep their existing passwords**; home dirs are renamed
too. Use when the boxes already have the old accounts.
- Linux: `provision_migrate.sh` → `migrate_linux.yml`
- DC:    `migrate_dc.ps1`
- Map:   `migration_map.csv` (old username → new username, with passwords)

**B) BUILD FROM SCRATCH** — delete existing accounts and create the roster fresh
with assigned rockyou passwords. Use for a clean/greenfield box.
- Linux: `provision_range.sh` → `cleanup_linux.yml` + `deploy_linux.yml`
- DC:    `provision_dc.ps1`
- Roster: `ansible_south_torbia_users.csv` / `ansible_north_torbia_users.csv`

Both keep `csra_admin` protected, run a dry-run first, and write reports to `reports/`.

## ⚠️ Private repo — contains the answer key
The `ansible_*_torbia_users.csv` rosters contain **plaintext exercise passwords**
(rockyou) and **are committed** here on purpose, so one clone builds the whole
range. **Keep this repository private.** Do not mirror it to a shared/public
remote. Credentials/vault files are still excluded (see `.gitignore`).

## Reports
`provision_range.sh` writes timestamped logs to `reports/` each run (gitignored):
`dryrun_summary_<ts>.txt` (clean list of WOULD REMOVE / KEEPING), plus full logs
for the dry-run, delete, and create steps — so you can read results in an editor
instead of scrolling the terminal.

## Layout
| File | Purpose |
|------|---------|
| `provision_migrate.sh` | **MIGRATE (Linux):** enter IPs, dry-run, confirm, rename old→new, keep passwords |
| `migrate_linux.yml` | Rename playbook (usermod -l + move home; password preserved) |
| `migrate_dc.ps1` | **MIGRATE (DC):** rename AD accounts old→new on the DC, keep passwords |
| `migration_map.csv` | old username/password → new S. Torbia username |
| `provision_range.sh` | BUILD: enter IP ranges, dry-run, confirm, delete + create (Linux) |
| `verify.sh` | Post-run check: SSH to each host and confirm the new usernames exist |
| `cleanup_linux.yml` | Remove old Linux accounts (keeps `csra_admin`), dry-run by default |
| `deploy_linux.yml` | Create roster on Linux |
| `cleanup_windows_ad.yml` | Remove old AD users in an OU (keeps `csra_admin`) |
| `relax_ad_password_policy.yml` | Let weak passwords import on the DC (Ansible; needs 2.15+) |
| `provision_dc.ps1` | **DC provisioning that runs on 2.9 setups** — PowerShell, runs on the DC itself (create/remove domain users, dry-run + report, csra_admin protected) |
| `deploy_windows_ad.yml` | Create roster in AD |
| `inventory.ini` | Hosts (edit for the DC; Linux IPs come from the script) |
| `TUTORIAL.md` / `QUICKSTART_SOUTH.md` | Full and quick walkthroughs |

## Quick start (Linux)
```bash
ansible-galaxy collection install community.general ansible.windows microsoft.ad
# place the roster CSV(s) in this folder (they are gitignored)
./provision_range.sh          # enter IP ranges -> dry-run -> type YES
```

## Requirements
- Ansible 2.9+ on the control node, `community.general` collection
- `csra_admin` reachable by SSH (Linux) / WinRM (DC)
- `sshpass` only if using SSH passwords instead of keys

See `TUTORIAL.md` for the DC steps and full detail.
