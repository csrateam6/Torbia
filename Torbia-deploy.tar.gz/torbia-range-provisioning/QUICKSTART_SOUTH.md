# South Torbia — Quick Migrate (rename old accounts → new, keep passwords)

Renames the existing baseline accounts to the new S. Torbia names and keeps
their current passwords (home dirs renamed too). Runs from any control node that
can SSH to the boxes as `csra_admin`. `csra_admin`/`root` are never touched.

> For a clean build-from-scratch instead (delete + create with rockyou
> passwords), use `provision_range.sh` / `provision_dc.ps1` — see README.

## 1. One-time setup on the control node
```bash
python3 -m pip install --user ansible        # 2.9+; migration uses bundled modules only
sudo apt install -y sshpass                   # only if you use SSH passwords, not keys
```
`ansible.cfg` ships in the kit (forks/timeouts tuned) — nothing to recreate.

## 2. Unpack
```bash
tar -xzf torbia-range-provisioning.tar.gz
cd torbia-range-provisioning
chmod +x provision_migrate.sh verify.sh
```

## 3. Linux boxes — one command
```bash
./provision_migrate.sh
```
Prompts:
- **Migration map CSV:** Enter (defaults to `migration_map.csv`)
- **IP ranges:** Enter (saved default = the 12 South hosts), or type your own
- **SSH password:** blank if key auth
- **sudo password:** blank if NOPASSWD

It runs a DRY RUN first — read the **WILL RENAME / OLD NOT FOUND / NEW ALREADY
EXISTS** plan in `reports/migrate_summary_*.txt` — then type **YES** to apply.

## 4. Domain Controller — run `migrate_dc.ps1` ON the DC
```bash
scp migrate_dc.ps1 migration_map.csv csra_admin@172.24.18.5:C:/Users/csra_admin/
ssh csra_admin@172.24.18.5
```
Then on the DC:
```
cd C:\Users\csra_admin
powershell -ExecutionPolicy Bypass -File migrate_dc.ps1            # DRY RUN
powershell -ExecutionPolicy Bypass -File migrate_dc.ps1 -Execute   # apply
```
Renames each AD account's SamAccountName/UPN/display name to the new values;
password preserved. `csra_admin` untouched.

## 5. Verify
```bash
./verify.sh                       # Linux: checks new usernames exist on each host
# DC:
#   powershell -c "Get-ADUser -Filter * | Select SamAccountName,Enabled"
```
Spot-check a few renamed users resolve, e.g. `yiseo.choi`, `seoah.lee`, `eunwoo.jeong`.

---
Linux = `provision_migrate.sh`; DC = `migrate_dc.ps1`. Passwords carry over from
the old accounts (so e.g. `seoah.lee` keeps `dragon`, `eunwoo.jeong` keeps `iloveyou`).
