<#
=============================================================================
 migrate_dc.ps1  —  Rename existing ATROPIA domain accounts to the new
                    S. Torbia names, keeping their passwords.

 Run ON the DC (172.24.18.5). For each row in migration_map.csv it renames the
 old account: SamAccountName, UPN, display name and CN -> new values. The
 PASSWORD IS KEPT (rename does not reset it). csra_admin is never touched.

 Copy script + CSV to the DC, then:
   powershell -ExecutionPolicy Bypass -File migrate_dc.ps1               # DRY RUN
   powershell -ExecutionPolicy Bypass -File migrate_dc.ps1 -Execute     # apply
=============================================================================
#>
[CmdletBinding()]
param(
  [string]$CsvPath     = ".\migration_map.csv",
  [string]$ProtectUser = "csra_admin",
  [switch]$Execute
)

$ErrorActionPreference = "Stop"
Import-Module ActiveDirectory

$domain = Get-ADDomain
$dns    = $domain.DNSRoot
$protected = @($ProtectUser,"Administrator","krbtgt","Guest") | ForEach-Object { $_.ToLower() }

$ts = Get-Date -Format "yyyyMMdd_HHmmss"
if (-not (Test-Path ".\reports")) { New-Item -ItemType Directory ".\reports" | Out-Null }
$report = ".\reports\dc_migrate_$ts.txt"
function Log($m){ $m | Tee-Object -FilePath $report -Append }

$mode = if ($Execute) { "EXECUTE" } else { "DRY RUN" }
Log "=== Torbia DC migration [$mode]  $(Get-Date) ==="
Log "Domain: $dns    CSV: $CsvPath    Protected: $($protected -join ', ')"

if (-not (Test-Path $CsvPath)) { Log "ERROR: CSV not found: $CsvPath"; exit 1 }
$map = Import-Csv $CsvPath
Log "Mappings: $($map.Count)"
Log ""

$willRename=@(); $missingOld=@(); $newExists=@()
foreach ($r in $map) {
  $old=$r.username; $new=$r.s_torbia_username
  if ($protected -contains $old.ToLower() -or $protected -contains $new.ToLower()) { continue }
  $o = Get-ADUser -Filter "SamAccountName -eq '$old'" -ErrorAction SilentlyContinue
  $n = Get-ADUser -Filter "SamAccountName -eq '$new'" -ErrorAction SilentlyContinue
  if (-not $o)      { $missingOld += $old; continue }
  if ($n)           { $newExists  += $new; continue }
  $willRename += "$old -> $new"
}
Log "WILL RENAME ($($willRename.Count)):";   $willRename | ForEach-Object { Log "  $_" }
Log "OLD NOT FOUND ($($missingOld.Count)): $($missingOld -join ', ')"
Log "NEW ALREADY EXISTS ($($newExists.Count)): $($newExists -join ', ')"
Log ""

if (-not $Execute) { Log "DRY RUN complete. Re-run with -Execute to apply. Report: $report"; exit 0 }

$done=0
foreach ($r in $map) {
  $old=$r.username; $new=$r.s_torbia_username
  if ($protected -contains $old.ToLower() -or $protected -contains $new.ToLower()) { continue }
  $o = Get-ADUser -Filter "SamAccountName -eq '$old'" -Properties DisplayName -ErrorAction SilentlyContinue
  if (-not $o) { continue }
  if (Get-ADUser -Filter "SamAccountName -eq '$new'" -ErrorAction SilentlyContinue) { continue }

  # rename identity attributes; password is left untouched
  Set-ADUser -Identity $o.DistinguishedName `
    -SamAccountName $new `
    -UserPrincipalName "$new@$dns" `
    -GivenName $r.s_torbia_fname -Surname $r.s_torbia_lname `
    -DisplayName "$($r.s_torbia_fname) $($r.s_torbia_lname)"
  # rename the object (CN) to the new display name
  Rename-ADObject -Identity $o.DistinguishedName -NewName "$($r.s_torbia_fname) $($r.s_torbia_lname)"
  Log "renamed $old -> $new"
  $done++
}
Log ""
Log "=== Done. Renamed $done account(s). Passwords preserved. Report: $report ==="
