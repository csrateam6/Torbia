#!/usr/bin/env bash
# ===========================================================================
# provision_migrate.sh  —  Rename old accounts to the new S. Torbia names
#                          across IP ranges, over SSH as csra_admin.
#                          Keeps existing passwords. Home dirs renamed too.
#
# Prompts for the migration map CSV, target IPs, and csra_admin's SSH/sudo
# passwords. Runs a DRY RUN (shows the rename plan + writes a report), waits
# for YES, then applies. csra_admin/root are never renamed.
#
# Run from inside the kit folder:  ./provision_migrate.sh
# ===========================================================================
set -uo pipefail   # not -e: unreachable IPs make ansible exit non-zero
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ADMIN="csra_admin"
DEFAULT_CSV="migration_map.csv"

command -v ansible-playbook >/dev/null || { echo "ERROR: ansible-playbook not found on PATH."; exit 1; }

echo "=== Torbia account MIGRATION (rename old -> new, keep passwords) ==="

read -rp "Migration map CSV [${DEFAULT_CSV}]: " CSV
CSV="${CSV:-$DEFAULT_CSV}"
[[ -f "$CSV" ]] || { echo "ERROR: CSV not found: $CSV"; exit 1; }

echo
echo "Enter target IP ranges (CIDR 10.0.0.0/24, range 10.0.0.10-50, single 10.0.0.5)."
# Saved default ranges — press Enter to use these.
DEFAULT_RANGES="172.24.10.150 172.24.10.180 172.24.19.66 172.24.19.44 172.24.19.68 172.24.18.99 172.24.18.135 172.24.21.12 172.24.21.71 172.24.21.42 172.24.22.75 172.24.22.19"
read -rp "IP ranges [Enter = saved default]: " RANGES
RANGES="${RANGES:-$DEFAULT_RANGES}"
[[ -n "${RANGES// }" ]] || { echo "ERROR: no ranges entered."; exit 1; }

HOSTS="$(python3 - "$RANGES" <<'PY'
import sys, re, ipaddress
out, seen = [], set()
for tok in re.split(r'[,\s]+', sys.argv[1].strip()):
    if not tok: continue
    try:
        if '/' in tok:
            for h in ipaddress.ip_network(tok, strict=False).hosts(): out.append(str(h))
        elif '-' in tok:
            base, rng = tok.rsplit('.', 1); lo, hi = rng.split('-')
            for i in range(int(lo), int(hi) + 1): out.append(f"{base}.{i}")
        else:
            out.append(str(ipaddress.ip_address(tok)))
    except Exception as e:
        sys.stderr.write(f"skip {tok}: {e}\n")
for ip in out:
    if ip not in seen: seen.add(ip); print(ip)
PY
)"
[[ -n "$HOSTS" ]] || { echo "ERROR: no valid IPs parsed."; exit 1; }
COUNT="$(printf '%s\n' "$HOSTS" | grep -c .)"
echo; echo "Expanded to ${COUNT} host(s)."

echo
read -rsp "SSH password for ${ADMIN} (blank = key auth): " SSHPW; echo
read -rsp "sudo password for ${ADMIN} (blank = NOPASSWD):  " SUDOPW; echo
if [[ -n "$SSHPW" ]]; then
  command -v sshpass >/dev/null || { echo "ERROR: SSH password given but 'sshpass' not installed."; exit 1; }
fi

INV="$(mktemp)"; VARS="$(mktemp)"; chmod 600 "$INV" "$VARS"
cleanup(){ shred -u "$VARS" 2>/dev/null || rm -f "$VARS"; rm -f "$INV"; }
trap cleanup EXIT

{
  echo "[targets]"; printf '%s\n' "$HOSTS"; echo
  echo "[targets:vars]"
  echo "ansible_user=${ADMIN}"
  echo "ansible_connection=ssh"
} > "$INV"
{
  [[ -n "$SSHPW"  ]] && echo "ansible_ssh_pass: \"${SSHPW}\""
  [[ -n "$SUDOPW" ]] && echo "ansible_become_pass: \"${SUDOPW}\""
} > "$VARS"

export ANSIBLE_HOST_KEY_CHECKING=False
PB=(-i "$INV" -e @"$VARS" -e "target_group=targets" -e "csv_file=${CSV}")

TS="$(date +%Y%m%d_%H%M%S)"; mkdir -p reports
DRY_LOG="reports/migrate_dryrun_${TS}.log"
DRY_SUMMARY="reports/migrate_summary_${TS}.txt"

echo
echo ">>> STEP 1/2  DRY RUN: rename plan (nothing changed yet)   log -> ${DRY_LOG}"
ansible-playbook "${PB[@]}" migrate_linux.yml 2>&1 | tee "$DRY_LOG"

{
  echo "=== Torbia migration DRY-RUN summary  ($(date)) ==="
  echo "CSV: ${CSV}   Hosts: ${COUNT}"
  echo
  grep -E "WILL RENAME|OLD NOT FOUND|NEW ALREADY EXISTS|KEEPING" "$DRY_LOG" \
    | sed 's/^[[:space:]]*"//; s/",\?[[:space:]]*$//' || echo "(nothing captured)"
  echo
  echo "--- PLAY RECAP ---"; awk '/PLAY RECAP/{f=1} f' "$DRY_LOG"
} > "$DRY_SUMMARY"

echo
echo "Dry-run done. Review:  ${DRY_SUMMARY}"
echo
read -rp "Type YES to apply the renames (home dirs move, passwords kept): " OK
[[ "$OK" == "YES" ]] || { echo "Aborted. Nothing changed. Reports in reports/"; exit 0; }

APPLY_LOG="reports/migrate_apply_${TS}.log"
echo
echo ">>> STEP 2/2  Applying renames   log -> ${APPLY_LOG}"
ansible-playbook "${PB[@]}" -e confirm=yes migrate_linux.yml 2>&1 | tee "$APPLY_LOG"

echo
echo "=== Done. ${COUNT} host(s) processed from ${CSV}. Reports in reports/ ==="
